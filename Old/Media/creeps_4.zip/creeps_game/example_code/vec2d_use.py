from vec2d import vec2d


v = vec2d(-1, 1)
#~ u = vec2d(0, -1)
#~ u = vec2d(1, 0)

#~ print v.get_angle_between(u)

print v.angle
